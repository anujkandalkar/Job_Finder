function Register() {
  return (
    <div className="page">
      <h1>Find the most exciting startup jobs</h1>
    </div>
  );
}

export default Register;
