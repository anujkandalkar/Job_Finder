import "./FeaturedJobs.css";

import ziggoLogo from "../assets/job1.png";
import elisaLogo from "../assets/job2.png";
import rostelecomLogo from "../assets/job3.png";
import veoliaLogo from "../assets/job4.png";

const jobs = [
  {
    company: "Ziggo",
    title: "Digital Marketer",
    agency: "Creative Agency",
    location: "Athens, Greece",
    salary: "$3500 - $4000",
    type: "Full Time",
    time: "7 hours ago",
    logo: ziggoLogo
  },
  {
    company: "Elisa",
    title: "Digital Marketer",
    agency: "Creative Agency",
    location: "Athens, Greece",
    salary: "$3500 - $4000",
    type: "Full Time",
    time: "7 hours ago",
    logo: elisaLogo
  },
  {
    company: "Rostelecom",
    title: "Digital Marketer",
    agency: "Creative Agency",
    location: "Athens, Greece",
    salary: "$3500 - $4000",
    type: "Full Time",
    time: "7 hours ago",
    logo: rostelecomLogo
  },
  {
    company: "Veolia",
    title: "Digital Marketer",
    agency: "Creative Agency",
    location: "Athens, Greece",
    salary: "$3500 - $4000",
    type: "Full Time",
    time: "7 hours ago",
    logo: veoliaLogo
  }
];

export default FeaturedJobs;
