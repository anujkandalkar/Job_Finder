import { Link } from "react-router-dom";
import "./Navbar.css";

function Navbar(){
    return(
        <>
            <nav className="navbar">
                
                <div className="logo">
                    <h2>Job Finder</h2>
                    <span>Get your dream job</span>
                </div>
                <ul className="nav-links">
                    <li>
                        <Link to="/">Home</Link>
                    </li>
                    <li>
                        <Link to="/jobs">Find Jobs</Link>
                    </li>
                    <li>
                        <Link to="/about">About</Link>
                    </li>
                    <li>
                        <Link to="/contact">Contact</Link>
                    </li>

                    <div className="nav-button">
                        <Link to="/register" className="btn">Register</Link>
                        <Link to="/login" className="btn-outline">Login</Link>
                    </div>
                </ul>
            </nav>
        </>
    )
}
export default Navbar;